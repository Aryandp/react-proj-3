
import React from 'react';
//import ReactDOM from 'react-dom';
class HelloWorld extends React.Component {
  render() {
    var i=1;
    var myStyle = {
         fontSize: 100,
         color: '#FF0000'
      }
    return(

    <div>
    <h1 style={myStyle}>HelloWorld</h1>
      <h1>HelloWorld{5+5}</h1>
      {2+2}
   </div>
        // <p data-myattribute = "somevalue">This is the content!!!</p>
        // <h1>{i == 1 ? 'True!' : 'False'}</h1>
</div>
    )
  }
}
export default HelloWorld;
