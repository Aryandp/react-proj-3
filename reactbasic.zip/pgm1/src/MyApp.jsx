import React from 'react';

class MyApp extends React.Component {
   render() {
      return (
         <div>
            <Header/>
            <Content/>
         </div>
      );
   }
}
class Header extends React.Component {
   render() {
      return (
         <div>
            <h1>Header</h1>
            <h1>Hello, world!</h1>
     <h2>It is {new Date().toLocaleTimeString()}.</h2>
   </div>
         
      );
   }
}
class Content extends React.Component {
   render() {
      return (
         <div>
            <h2>Content</h2>
            <p>The content text!!!</p>
         </div>
      );
   }
}
export default MyApp;
