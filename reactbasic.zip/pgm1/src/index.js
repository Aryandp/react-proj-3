
import React from 'react';
import ReactDOM from 'react-dom';
/*--for HelloWorld code run this one--*/
//import HelloWorld from './HelloWorld.jsx';
//ReactDOM.render(<HelloWorld/>, document.getElementById('root'));

/*--for run Myapp stateless code this code*/
import MyApp from './MyApp.jsx';
ReactDOM.render(<MyApp/>, document.getElementById('root'));
setInterval(tick, 1000);

/*--for run App statelfull code this code
import App from './App.jsx';
ReactDOM.render(<App/>, document.getElementById('root'));*/

/*--for run App statelfull using Props code this code
import Props from './Props.jsx';
ReactDOM.render(<Props/>, document.getElementById('root'));*/
/*import Pg1 from './pg1.jsx';
ReactDOM.render(<Pg1/>,document.getElementById('root'))*/
