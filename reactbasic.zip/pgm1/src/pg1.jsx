import React from 'react';

class Pg1 extends React.Component {
   render() {
    /* var x = 5;
var y = 6;
var z;
var txt1 = "What a very "*/
      return (
         <div>
          /*  <h1>x={x} and y={y}</h1>
            <h2>value of z=
            {
 z=x + y}</h2>
 <h3> {txt1 += "nice day"}</h3>*/
<p>{function myFunction(p1, p2) {
    return p1 * p2} and {myFunction(4,3)}</p>

         </div>
      )
   }
}
export default Pg1;
